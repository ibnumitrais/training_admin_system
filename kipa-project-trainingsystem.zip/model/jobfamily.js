var config = {
    userName: 'thor',
    password: 's4teliliT',
    server: 'jptrainingsql', 
    database: 'TAS_Thor' 
};

var Connection = require('tedious').Connection;
var connection = new Connection(config);
var Request = require('tedious').Request;  
var TYPES = require('tedious').TYPES; 

module.exports = {

    getAllRecords: function(res) {

        request = new Request("SELECT * FROM Job_Family;", function(err) {  
        if (err) {  
            console.log(err);}  
        });  

        request.on('row', function(columns) {  
            res.end(JSON.stringify(columns));
        }); 

        connection.on('connect', function(err) {
            connection.execSql(request);
        })
    }
  };
